# Snrtr.com Film Scripti
Merhabalar bir süredir üzerinde çalıştığım film sitesi scriptini tamamlamış bulunmaktayım ve sizlerle paylaşıyorum.Hiçbir şekilde dosyalarda lisans ve şifreleme kulanmadım full açık kaynak kodlu bir şekilde sizlere sunulmuştur.
# Scriptin Kurulumu
film.sql dosyasını veritabanınıza yükleyin
admin/islem/baglan.php dosyası üzerindeki ayarlamaları kendi local sunucunuza göre ayarlayın.
Kurulum tamamlanmıştır.
# Admin Paneli
Kulacını adı : admin@admin.com
şifre : demo
Bu şekilde admin paneline girebilirsiniz.
# Script Demo
http://film.snrtr.com adresinden demo görünümünü görebilirsiniz fakat admin paneline giriş yapamazsınız onu test etmek için local sunucunuza kurmanız gerekecektiri.
Saygılarımla Soner USTA
